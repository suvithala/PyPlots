

```python
Analysis 
Observed Trend 1: There are more drivers in the Urban cities then Suburban and Rural areas.
Observed Trend 2: Average Fare price is also higher in rural areas.
Observed Trend 3: Total Rides, Total Drivers and Total Fares all are above 60% in Urban areas.

```


```python
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
sns.set(color_codes=True)
```


```python
# Load in csv
city_df = pd.read_csv("raw_data/city_data.csv")
city_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
ride_df = pd.read_csv("raw_data/ride_data.csv")
ride_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
city_ride_df = pd.merge(city_df, ride_df, on='city', how='outer')
city_ride_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
groupbycity_df = city_ride_df.groupby(['city','type'], as_index = False)
ride_df = groupbycity_df['ride_id'].count()
graph_df = ride_df.rename(columns={"ride_id":"Total Number of Rides (Per City)"})
graph_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>Total Number of Rides (Per City)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
avefare_percity= groupbycity_df["fare"].mean()
avefare_percity.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
graph_df["Average Fare ($)"] = avefare_percity["fare"]
graph_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>Total Number of Rides (Per City)</th>
      <th>Average Fare ($)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>31</td>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>26</td>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>9</td>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>22</td>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>19</td>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
drivers_percity= groupbycity_df["driver_count"].sum()
drivers_percity.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>driver_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>651</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>1742</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>144</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>462</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>931</td>
    </tr>
  </tbody>
</table>
</div>




```python
graph_df["Total Number of Drivers Per City"] = drivers_percity["driver_count"]
graph_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>Total Number of Rides (Per City)</th>
      <th>Average Fare ($)</th>
      <th>Total Number of Drivers Per City</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>31</td>
      <td>23.928710</td>
      <td>651</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>26</td>
      <td>20.609615</td>
      <td>1742</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>9</td>
      <td>37.315556</td>
      <td>144</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>22</td>
      <td>23.625000</td>
      <td>462</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>19</td>
      <td>21.981579</td>
      <td>931</td>
    </tr>
  </tbody>
</table>
</div>




```python
use_colors = {"U": "orange", "S": "blue", "R": "yellow"}
plt.figure(figsize=(15,10))
plt.scatter(x=graph_df['Total Number of Rides (Per City)'],
            y=graph_df['Average Fare ($)'],
            c=[use_colors[x[0]] for x in graph_df['type']],
            s=(graph_df['Total Number of Drivers Per City']*0.5),
            marker ='o',
            edgecolors='black',
            alpha=0.75
            )
plt.grid(True)
plt.grid(color="grey")
plt.title("Pyber Ride Sharing Data(2016)")
plt.xlabel('Total Number of Rides (Per City)')
plt.ylabel('Average Fare ($)')

#Create legend from custom artist/label lists
type1 = plt.scatter([],[], s=75, marker='o', color='orange', edgecolors='black')
type2 =  plt.scatter([],[], s=75, marker='o', color='blue', edgecolors='black')
type3 =  plt.scatter([],[], s=75, marker='o', color='yellow', edgecolors='black')
plt.legend((type1,type2,type3),
           ('Urban', 'Subarban', 'Rural'),
            scatterpoints=1,
            loc='upper right',
            ncol=1,
            fontsize=10,
            title='City Types')
plt.show()
```


![png](output_10_0.png)



```python
fare_bytype = city_ride_df['fare'].sum()
rides_bytype = city_ride_df['ride_id'].count()
drivers_bytype = city_ride_df['driver_count'].sum()
type_summary = pd.DataFrame([[fare_bytype,rides_bytype,drivers_bytype]])
type_summary.columns = ['Total Fare','Total Rides','Total Drivers']

```


```python
sorted_df = city_ride_df.sort_values('type')
groupbytype_df = sorted_df.groupby(['type'],as_index=False)
pie_df = groupbytype_df.ride_id.count()

```


```python
fare_byttype = groupbytype_df.fare.sum()
drivers_bytype = groupbytype_df.driver_count.sum()
pie_df['fare by type'] = fare_byttype.fare
pie_df['driver count'] = drivers_bytype.driver_count

```


```python
def fareperc(col):
    return (col/type_summary['Total Fare'])*100
def driverperc(col):
    return (col/type_summary['Total Drivers'])*100
def rideperc(col):
    return (col/type_summary['Total Rides'])*100
```


```python
pie_df['ride_perc'] = pie_df['ride_id'].apply(rideperc)
pie_df['fare_perc'] = pie_df['fare by type'].apply(fareperc)
pie_df['drive_perc'] = pie_df['driver count'].apply(driverperc)

```


```python
plt.figure(figsize=(8,8))
piecolors = {"U": "lightcoral", "S": "lightblue", "R": "orange"}
colors = [piecolors[x[0]] for x in pie_df['type']]
explode = (0,0,0.1) 
plt.pie(pie_df['fare_perc'], explode=explode, labels=pie_df['type'], colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=120)
plt.title("% of Total Fares by City Type")
plt.axis('equal')
plt.show()
```


![png](output_16_0.png)



```python
plt.figure(figsize=(8,8))
piecolors = {"U": "lightcoral", "S": "lightblue", "R": "orange"}
colors = [piecolors[x[0]]  for x in pie_df['type']]
explode = (0,0,0.1) 
plt.pie(pie_df['ride_perc'], explode=explode, labels=pie_df['type'], colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=130)
plt.title("Total Rides by City Type")
plt.axis('equal')
plt.show()
```


    <matplotlib.figure.Figure at 0x2902c4045f8>



![png](output_17_1.png)



```python
plt.figure(figsize=(8,8))
piecolors = {"U": "lightcoral", "S": "lightblue", "R": "orange"}
colors = [piecolors[x[0]] for x in pie_df['type']]
explode = (0,0,0.1) 
plt.pie(pie_df['drive_perc'], explode=explode, labels=pie_df['type'], colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=150)
plt.title("Total Drivers by City Type")
plt.axis('equal')
plt.show()
```


![png](output_18_0.png)

